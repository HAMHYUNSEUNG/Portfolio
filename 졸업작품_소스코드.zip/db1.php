<?php
$servername = "localhost";
$user = "alstjq9751";
$password = "flqjtm1!";
$dbname = "alstjq9751";

$connect = mysqli_connect($servername, $user, $password, $dbname);
if (!$connect) {

    die("서버와의 연결 실패! : ".mysqli_connect_error());

}
?>