<?php
include "db1.php";
require_once "session_start.php";
$query = "SELECT * FROM sign_up WHERE student_number = $session_id";
$result = mysqli_query($connect, $query);
$row = mysqli_fetch_array($result);

$name = $row['name'];
?>
<!DOCTYPE html>
<html lang="ko">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>캡스톤 디자인</title>
    <link href="https://fonts.googleapis.com/css?family=Do+Hyeon|Indie+Flower&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Josefin+Sans&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/privacy.css">
    <link rel="stylesheet" href="css/base.css">
</head>

<body>

    <!-- header / navbar -->
    <script src ='js/navbar.js'></script> 
    <script src ='sidnav.js'></script>


    <article>
        
        <div class="atc_tbl">
            <form action="change_info.php" method="post">
                <table>
                    <tr>
                        <td class="left">학과</td>
                        <td class="right"><input type="text" name="dept" value="컴퓨터소프트웨어"></td>
                    </tr>
                    <tr>
                        <td>학번</td>
                        <td><input type="text" name="userID" value=" <?php echo"$session_id";  ?>"></td>
                    </tr>
                    <tr>
                        <td>이름</td>
                        <td><input type="text" name="name" value=" <?php echo "$name"; ?>"></td>
                    </tr>
                    <tr>
                        <td>담당교수</td>
                        <td><select name="prof" id="prof">
                                <option>김점구</option>
                                <option>김정길</option>
                                <option>문송철</option>
                                <option>나상엽</option>
                                <option>정지문</option>
                            </select>
                        </td>
                        </tr>
                        <tr>
                            <td>조 원</td>
                            <td>
                                <select style="width:40%;height:30px;" name="group">
                                    <option>1조</option>
                                    <option>2조</option>
                                    <option>3조</option>
                                    <option>4조</option>
                                    <option>5조</option>
                                </select>
                            </td>
                        </tr>
                </table>
                <div class="infoch_bt" id="infochh_bt">
                    <button type="submit" id="chinfo_bt" name="chinfo_bt"> 변경하기 </button>
                </div>
            </form>
        </div>

    </article>

    <!-- footer -->
    <script src='js/footer.js'></script>

    <script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
    <script src="js/bootstrap.js"></script>
</body>

</html>