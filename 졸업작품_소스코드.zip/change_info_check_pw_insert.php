<?php
   include "db1.php";
   require_once "session_start.php";
 

 $pw = $_POST['check_pw']; 
 

 $query = "SELECT * FROM sign_up WHERE student_number = $session_id AND pw = SHA('$pw')";
 $result = mysqli_query($connect, $query);
 if(!$result || mysqli_num_rows($result)==1){
    echo '<script>document.location.href="./change_info_first.php"</script>';
 }else{
    echo '<script>alert("비밀번호가 틀립니다!"); history.back(); </script>';
 }
?>