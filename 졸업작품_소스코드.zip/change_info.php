<?php
    include "db1.php";
    require_once "session_start.php";
   
    //일단 2가지 추후 수정 요망 
    $professor = $_POST['prof'];
    $team = $_POST['group'];
    
    
    if( $professor==NULL || $team==NULL ){
        echo'<script>alert("빈 칸을 모두 채워주세요!"); history.back();</script>';
    }else{//아직 추가해줘야함 
        $sql = "UPDATE sign_up SET professor = '$professor', team = '$team' WHERE student_number = '$session_id'";
        if(mysqli_query($connect, $sql)){
            echo "<script>alert('변경 완료되었습니다.'); location.href='privacy.php';</script>";
            mysqli_close($connection);
        }else{
            echo'<script>alert("DB오류입니다! 관리자에게 문의하십시오!");history.back(); </script>';
        }
    }
?>