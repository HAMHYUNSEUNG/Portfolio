<?php
 require_once "session_start.php";
?>
<!DOCTYPE html>
<html lang="ko">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel="stylesheet" href="css/bootstrap.css">
        <link rel= "stylesheet" type="text/css" href="css/my_infomation.css">
        <link href="https://fonts.googleapis.com/css?family=Nanum+Gothic:400,700,800&amp;subset=korean" rel="stylesheet">
        <title>캡스톤 디자인</title>
    </head>
    <body>  
        <style type="text/css">
            .jumbotron {
                background-image: url("img/background.png");
                background-size: cover;
                text-shadow: black 0.2em 0.2em 0.2em;
                color: white;

            }
        </style>
        <?php
        echo "<script src ='navbar.js'></script>"; // 내비게이션바
        echo "<script src ='sidnav.js'></script>"; // 사이드바
        ?>


        <section class="section">
            <div id="contents">
                <div class="myAuth">
                    <h2>
                        <img src="tit_userinfo.gif" width="427" height="30" alt="개인정보변경 - 개인정보보호를 위해 최선을 다하겠습니다." >
                    </h2>
                    <p class="authTxt">
                        <strong>비밀번호</strong>   를 입력해주세요.
                    </p>
                    <div class="numberInput">
                        <form action="change_info_check_pw_insert.php" method="POST">
                        <dl class="pw">
                            <dt class="ch_pw">
                                비밀번호 확인
                            </dt>
                            <dt class="in_pw">
                                <input type="password" name="check_pw"  id="in_pw">
                            </dt>
                        </dl>
                        <p class="check_bt">
                            <button type="submit" id="check_bt" name="check_bt">
                                확인
                            </button>
                        </p>
                        </form>
                    </div>
                </div>
            </div>
        </section>





        <script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
        <script src="js/bootstrap.js"></script>
    </body>
</html>